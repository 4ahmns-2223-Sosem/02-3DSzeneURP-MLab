using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sunlight : MonoBehaviour
{
    public int score = 0; // Die aktuelle Punktzahl

    private void OnTriggerEnter(Collider other)
    {
        // Überprüfen, ob das andere Objekt ein Trigger ist
        if (other.isTrigger)
        {
            InvokeRepeating("IncreaseScore", 1f, 1f); // Jede Sekunde die Punktzahl erhöhen
        }
    }

    private void OnTriggerExit(Collider other)
    {
        // Überprüfen, ob das andere Objekt ein Trigger ist
        if (other.isTrigger)
        {
            CancelInvoke("IncreaseScore"); // Aufhören, die Punktzahl zu erhöhen, wenn der Trigger verlassen wird
        }
    }

    private void IncreaseScore()
    {
        score += 10; // Punktzahl um 10 erhöhen
        Debug.Log("Score: " + score);
    }
}
