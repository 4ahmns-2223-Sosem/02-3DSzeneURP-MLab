using UnityEngine;

public class Array : MonoBehaviour
{
    public GameObject prefab; 
    public int numberOfObjects = 10; 

    private GameObject[] objectArray; 

    private void Start()
    {
        
        objectArray = new GameObject[numberOfObjects];

        
        for (int i = 0; i < numberOfObjects; i++)
        {
            GameObject obj = Instantiate(prefab); 
            objectArray[i] = obj; 
        }
    }
}
