using UnityEngine;
using UnityEngine.SceneManagement;

public class Buttonklick : MonoBehaviour
{
    public int requiredEnergyGluehbirne = 10;

    public int requiredEnergyGrossstadt = 30;

    public int requiredEnergyKleinstadt = 20;

    public int currentEnergy;

    public GameObject GluehBirne;
    public GameObject KleinStadt;
    public GameObject GrossStadt;
    public GameObject targetObject;
    public GameObject solarPanel;


    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == targetObject)
        {
            Debug.Log("score wird increased");
            InvokeRepeating("IncreaseScore", 1f, 1f); // Jede Sekunde die Punktzahl erhöhen
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject == targetObject)
        {
            CancelInvoke("IncreaseScore"); // Aufhören, die Punktzahl zu erhöhen, wenn der Trigger verlassen wird
        }
    }

    private void IncreaseScore()
    {
        currentEnergy += 10; // Punktzahl um 10 erhöhen
        Debug.Log("Score: " + currentEnergy);
    }

    private void OnMouseDown()
    {
        if (currentEnergy >= requiredEnergyGluehbirne)
        {
            
            //SceneManager.LoadScene("Lobby");
            Debug.Log("Birne wird beleuchtet!");

        }

        else
        {
            
            Debug.Log("Nicht genügend Energiepunkte!");
        }
    }
    void Start()
    {
        
    }
    
    public void EnlightLocations(int energyLevel)
    {
        if (energyLevel >= 0 && energyLevel <= requiredEnergyGluehbirne)
        {

            GluehBirne.SetActive(true);
            Debug.Log("Birne wird beleuchtet!");
            GrossStadt.SetActive(false);
            KleinStadt.SetActive(false);

        }

        else if (energyLevel > requiredEnergyGluehbirne && energyLevel <= requiredEnergyKleinstadt)
        {
            KleinStadt.SetActive(true);
            Debug.Log("Stadt wird beleuchtet!");
            GrossStadt.SetActive(false);
        }

        else if (energyLevel >= requiredEnergyKleinstadt && energyLevel<= requiredEnergyGrossstadt)
        {
            GrossStadt.SetActive(true);
            Debug.Log("Stadt wird beleuchtet!");
        }
    }

    private void Update()
    {
        EnlightLocations(currentEnergy);
    }

}


